CS 640 Assignment 4 - trying a different approach!
